import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Tech from './pages/Tech';
import Musings from './pages/Musings';
import Travel from './pages/Travel';

export default function App() {
  return (
    <div className="min-h-screen bg-white text-black">
      <Navbar />
      <h1 className="text-4xl p-6 text-red-500">🌟 Hello from App.jsx</h1>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/tech" element={<Tech />} />
        <Route path="/musings" element={<Musings />} />
        <Route path="/travel" element={<Travel />} />
      </Routes>
    </div>
  );
}