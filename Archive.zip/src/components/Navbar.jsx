import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav className="flex gap-6 p-6 border-b">
      <Link to="/" className="hover:underline">Home</Link>
      <Link to="/tech" className="hover:underline">Tech</Link>
      <Link to="/musings" className="hover:underline">Musings</Link>
      <Link to="/travel" className="hover:underline">Travel</Link>
    </nav>
  );
}