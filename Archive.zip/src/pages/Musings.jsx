export default function Musings() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-4">Musings</h1>
      <p className="text-lg">Poetry, essays, and random thoughts.</p>
    </div>
  );
}